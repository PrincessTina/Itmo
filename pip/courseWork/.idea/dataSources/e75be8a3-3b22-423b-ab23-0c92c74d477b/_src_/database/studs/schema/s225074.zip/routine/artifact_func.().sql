create function artifact_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.art_id:= NEXTVAL('artifact_seq');
RETURN new;
END;
$$;
