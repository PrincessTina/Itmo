create function st_addband(rast raster, index integer, pixeltype text, initialvalue double precision DEFAULT '0'::numeric, nodataval double precision DEFAULT NULL::double precision) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT  public.ST_addband($1, ARRAY[ROW($2, $3, $4, $5)]::addbandarg[])
$$;
