create function earth_distance(earth, earth) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT sec_to_gc(cube_distance($1, $2))
$$;
