create function st_polygonfromtext(text, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_PolyFromText($1, $2)
$$;
