create function st_pixelofvalue(rast raster, search double precision, exclude_nodata_value boolean DEFAULT true, OUT x integer, OUT y integer) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT x, y FROM public.ST_PixelOfValue($1, 1, ARRAY[$2], $3)
$$;
