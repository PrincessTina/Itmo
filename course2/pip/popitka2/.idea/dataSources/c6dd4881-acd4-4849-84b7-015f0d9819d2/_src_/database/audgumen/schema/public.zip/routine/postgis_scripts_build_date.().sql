create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2017-09-30 19:58:55'::text AS version
$$;
