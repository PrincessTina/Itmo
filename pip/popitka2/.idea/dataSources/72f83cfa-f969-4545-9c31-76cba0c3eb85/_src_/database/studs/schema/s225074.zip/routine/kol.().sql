create function kol() returns integer
LANGUAGE plpgsql
AS $$
  <<outerblock>>
DECLARE kol integer:= 0;
BEGIN
SAVEPOINT kol0;
UPDATE AUTHOR SET count_of_legend = (SELECT COUNT(*) FROM LEGEND WHERE LEGEND.author_id = new.author_id);
kol:= new.count_of_legend;
ROLLBACK TO SAVEPOINT kol0;
RETURN kol;
END;
$$;
