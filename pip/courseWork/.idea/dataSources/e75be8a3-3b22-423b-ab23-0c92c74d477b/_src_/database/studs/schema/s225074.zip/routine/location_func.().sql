create function location_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.location_id:= NEXTVAL('location_seq');
RETURN new;
END;
$$;
