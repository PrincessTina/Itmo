create function st_valuepercent(rast raster, searchvalue double precision, roundto double precision DEFAULT 0) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ( public._ST_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).percent
$$;
