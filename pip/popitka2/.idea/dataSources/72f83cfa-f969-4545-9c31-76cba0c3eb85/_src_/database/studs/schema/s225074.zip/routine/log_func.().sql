create function log_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.log_id:= NEXTVAL('log_seq');
RETURN new;
END;
$$;
