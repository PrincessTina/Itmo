create function event_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.event_id:= NEXTVAL('event_seq');
RETURN new;
END;
$$;
