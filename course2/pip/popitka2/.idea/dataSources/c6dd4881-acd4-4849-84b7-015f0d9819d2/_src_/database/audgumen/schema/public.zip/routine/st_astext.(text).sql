create function st_astext(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_AsText($1::public.geometry);
$$;
