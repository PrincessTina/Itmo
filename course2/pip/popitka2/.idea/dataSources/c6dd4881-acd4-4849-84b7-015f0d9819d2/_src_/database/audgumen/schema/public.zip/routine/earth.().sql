create function earth() returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '6378168'::float8
$$;
