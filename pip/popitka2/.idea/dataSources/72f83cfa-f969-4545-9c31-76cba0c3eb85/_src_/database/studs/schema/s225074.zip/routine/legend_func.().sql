create function legend_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.legend_id:= NEXTVAL('legend_seq');
RETURN new;
END;
$$;
