create function achievement_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.ach_id:= NEXTVAL('achievement_seq');
RETURN new;
END;
$$;
