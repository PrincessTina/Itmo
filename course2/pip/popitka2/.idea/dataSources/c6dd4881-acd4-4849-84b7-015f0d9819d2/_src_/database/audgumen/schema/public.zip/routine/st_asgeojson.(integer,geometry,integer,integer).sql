create function st_asgeojson(gj_version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4);
$$;
