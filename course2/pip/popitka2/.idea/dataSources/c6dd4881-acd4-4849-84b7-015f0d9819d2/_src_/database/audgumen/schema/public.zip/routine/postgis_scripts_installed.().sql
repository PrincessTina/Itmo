create function postgis_scripts_installed() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.4.0'::text || ' r' || 15853::text AS version
$$;
