create function country_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.country_id:= NEXTVAL('country_seq');
RETURN new;
END;
$$;
