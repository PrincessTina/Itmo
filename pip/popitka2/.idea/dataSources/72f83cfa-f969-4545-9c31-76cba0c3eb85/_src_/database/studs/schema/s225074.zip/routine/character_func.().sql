create function character_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.character_id:= NEXTVAL('character_seq');
RETURN new;
END;
$$;
