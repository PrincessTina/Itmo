create function user_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.user_id:= NEXTVAL('user_seq');
RETURN new;
END;
$$;
