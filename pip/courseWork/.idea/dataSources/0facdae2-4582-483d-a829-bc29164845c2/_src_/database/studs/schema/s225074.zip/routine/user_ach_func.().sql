create function user_ach_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
INSERT INTO USER_ACHIEVEMENT(user_id, ach_id) (SELECT user_id, ach_id FROM LOG INNER JOIN EVENT ON (EVENT.legend_id = LOG.legend_id) INNER JOIN ACHIEVEMENT USING(event_id) WHERE (LOG.legend_id = new.legend_id AND LOG.user_id = new.user_id));
RETURN new;
END;
$$;
