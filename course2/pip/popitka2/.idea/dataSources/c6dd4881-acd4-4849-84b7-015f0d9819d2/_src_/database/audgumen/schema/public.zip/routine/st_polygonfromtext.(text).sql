create function st_polygonfromtext(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_PolyFromText($1)
$$;
