create function achfunc() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
INSERT INTO ACHIEVEMENT(event_id, description)
VALUES(new.event_id, 'Completed Event "' || new.description || '"');
RETURN new;
END;
$$;
