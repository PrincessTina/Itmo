create function author_func() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
new.author_id:= NEXTVAL('author_seq');
RETURN new;
END;
$$;
