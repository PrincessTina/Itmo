create function st_aspng(rast raster, nband integer, options text[] DEFAULT NULL::text[]) returns bytea
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.st_aspng(st_band($1, $2), $3)
$$;
