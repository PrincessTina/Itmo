create function st_aspng(rast raster, nband integer, compression integer) returns bytea
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.st_aspng($1, ARRAY[$2], $3)
$$;
