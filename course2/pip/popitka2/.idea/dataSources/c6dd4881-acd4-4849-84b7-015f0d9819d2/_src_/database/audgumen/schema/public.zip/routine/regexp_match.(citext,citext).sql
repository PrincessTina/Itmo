create function regexp_match(citext, citext) returns text[]
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT pg_catalog.regexp_match( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;
